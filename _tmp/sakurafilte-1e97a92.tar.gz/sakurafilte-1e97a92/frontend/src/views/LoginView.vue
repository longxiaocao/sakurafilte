<script setup lang="ts">
// 后台登录界面 (JWT 改造版 + P2.6 i18n 全量接入)
//   - 调用后端 POST /api/auth/login, 写入 useAdminAuthStore (JWT 全字段)
//   - 支持 redirect 查询参数, 登录后回跳到原目标页
//   - 错误码 ERR_AUTH_FAILED → 友好提示 (通过 i18n 映射)
//   - 主题切换兼容: 全部使用 CSS 变量, 跟随 <html class="dark">
import { reactive, ref, onMounted, onBeforeUnmount, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { User, Lock } from '@element-plus/icons-vue'
import { useAdminAuthStore } from '@/composables/useAdminAuth'
import { authApi } from '@/api'
import { useI18n } from 'vue-i18n'
import { isSafeRedirect, parseRedirectHosts } from '@/utils/security'

const router = useRouter()
const route = useRoute()
const auth = useAdminAuthStore()
const { t } = useI18n()

// V2 Task V17-3.3: 开放重定向防护 - 启动时解析一次白名单主机
//   WHY 模块级常量: 环境变量编译期注入,运行时不变,无需每次登录重复解析
const SAFE_REDIRECT_HOSTS = parseRedirectHosts(import.meta.env.VITE_SAFE_REDIRECT_HOSTS)

const form = reactive({
  username: '',
  password: ''
})
const loading = ref(false)
const errorMsg = ref('')

// 🔧 fix(审查): Cloudflare Turnstile 人机验证 — 后端 Turnstile:SiteKey 配置后强制;
//   未配置 (开发/演示) 不渲染 widget, 不阻塞登录
const turnstileWidget = ref<HTMLDivElement | null>(null)
const turnstileToken = ref('')
const turnstileError = ref('')  // 🔧 fix(审查): 渲染失败明确提示 (CF 侧 domain 不匹配等, 避免用户锁死且不知原因)
const turnstileLoaded = ref(false)
let turnstileRenderTimer: ReturnType<typeof setTimeout> | null = null

async function initTurnstile() {
  try {
    const cfg = await authApi.turnstileConfig()
    if (!cfg.siteKey) return  // 未配置, 跳过
    await nextTick()
    const loaded = await loadTurnstileScript()
    if (!loaded) {
      // 脚本加载失败/超时 (网络无法访问 challenges.cloudflare.com) → 明确提示
      turnstileLoaded.value = true
      turnstileError.value = t('auth.turnstileUnavailable')
      return
    }
    renderTurnstile(cfg.siteKey)
  } catch {
    turnstileError.value = t('auth.turnstileUnavailable')
  }
}

function loadTurnstileScript(): Promise<boolean> {
  return new Promise((resolve) => {
    // @ts-ignore — window.turnstile 来自 CF 脚本
    if (window.turnstile || document.querySelector('script[data-turnstile]')) { resolve(true); return }
    const s = document.createElement('script')
    s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit'
    s.dataset.turnstile = '1'
    let done = false
    const finish = (ok: boolean) => { if (!done) { done = true; resolve(ok) } }
    s.onload = () => finish(true)
    s.onerror = () => finish(false)
    document.head.appendChild(s)
    // 8 秒超时: 国内/受限网络访问 CF CDN 慢或失败 → 不再等待, 走明确提示
    setTimeout(() => finish(false), 8000)
  })
}

function renderTurnstile(siteKey: string) {
  turnstileLoaded.value = true
  // v-if 依赖 turnstileLoaded → 需等下一轮渲染后再挂 widget
  nextTick(() => {
    if (!turnstileWidget.value) return
    try {
      // @ts-ignore — window.turnstile 来自 CF 脚本
      window.turnstile.render(turnstileWidget.value, {
        sitekey: siteKey,
        theme: document.documentElement.classList.contains('dark') ? 'dark' : 'light',
        callback: (token: string) => { turnstileToken.value = token; turnstileError.value = '' },
        'error-callback': () => { turnstileError.value = t('auth.turnstileUnavailable') },
      })
      // 3 秒检测: iframe 未出现 = CF 侧拒绝渲染 (Site Key 域名未包含当前访问域名)
      turnstileRenderTimer = setTimeout(() => {
        if (!turnstileToken.value && !turnstileWidget.value?.querySelector('iframe')) {
          turnstileError.value = t('auth.turnstileUnavailable')
        }
      }, 3000)
    } catch {
      turnstileError.value = t('auth.turnstileUnavailable')
    }
  })
}

// 主题切换时重渲染 (widget 主题跟随)
function onThemeChange() {
  if (!turnstileLoaded.value || !turnstileWidget.value) return
  // @ts-ignore — window.turnstile 来自 CF 脚本
  if (window.turnstile?.reset) {
    // @ts-ignore
    window.turnstile.reset(turnstileWidget.value)
  }
}

onMounted(() => { initTurnstile() })
onBeforeUnmount(() => {
  if (turnstileRenderTimer) clearTimeout(turnstileRenderTimer)
})

// 后端 errorCode → i18n key 映射
const AUTH_ERROR_I18N: Record<string, string> = {
  ERR_AUTH_FAILED: 'auth.authFailed',
  ERR_USER_DISABLED: 'auth.userDisabled',
  ERR_USER_LOCKED: 'auth.userLocked'
}

async function handleLogin() {
  // 🔧 fix(审查): 防重入 — loading 期间重复触发 (双击按钮/快速 Enter) 只发一次请求
  if (loading.value) return
  // 输入校验: 前端兜底, 避免空请求
  if (!form.username || !form.password) {
    errorMsg.value = t('auth.usernamePlaceholder') + ' / ' + t('auth.passwordPlaceholder')
    return
  }
  loading.value = true
  errorMsg.value = ''
  // 🔧 fix(审查): Turnstile 配置了 siteKey 时, 必须完成人机验证 (token 非空)
  const siteKeyConfigured = turnstileLoaded.value
  if (siteKeyConfigured && !turnstileToken.value) {
    loading.value = false
    errorMsg.value = turnstileError.value || t('auth.turnstileRequired')
    return
  }
  try {
    const payload = await authApi.login(form.username, form.password, turnstileToken.value || undefined)
    auth.setAuth(payload)
    ElMessage.success(t('auth.loginSuccess'))
    // V2 Task V17-3.3: 开放重定向防护 - 仅允许同源相对路径或白名单主机
    //   WHY 修复: 之前 `route.query.redirect as string` 强转可被构造 javascript:evil() 或钓鱼站点
    // V24-F33 (spec F5-9/Task 4.5.23.4): 优先用 returnUrl (新参数名), 向后兼容 redirect (旧参数)
    //   WHY: http.ts handle401 改用 ?return= 替代 ?redirect=, 但旧分享链接可能仍含 redirect=
    //        兼容期同时支持两个参数名, 后续版本可移除 redirect 兼容
    const returnUrlRaw = (route.query.return as string | undefined) ?? (route.query.redirect as string | undefined)
    const safeReturn = isSafeRedirect(returnUrlRaw, SAFE_REDIRECT_HOSTS)
    // V24-F33: spec F5-9 用 router.replace 替代 router.push (登录回跳不入 history 栈, 避免后退回到登录页)
    router.replace(safeReturn ? returnUrlRaw! : '/admin/products')
  } catch (e: any) {
    // 后端 ProblemDetails.errorCode 优先, 走 i18n 映射; title 兜底
    const errorCode = e?.response?.data?.errorCode
    const title = e?.response?.data?.title
    if (errorCode && AUTH_ERROR_I18N[errorCode]) {
      errorMsg.value = t(AUTH_ERROR_I18N[errorCode])
    } else if (title) {
      errorMsg.value = title
    } else {
      errorMsg.value = t('auth.loginFailed')
    }
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="login-page min-h-screen flex items-center justify-center p-4 bg-[var(--color-bg)]">
    <div
      class="login-card w-full max-w-sm hairline p-8 bg-[var(--color-bg-elevated)]"
      :aria-label="t('auth.title')"
    >
      <div class="text-center mb-6">
        <h1 class="text-2xl font-medium tracking-tight">{{ t('auth.title') }}</h1>
        <p class="text-sm text-muted mt-1">{{ t('auth.subtitle') }}</p>
      </div>

      <form class="space-y-4" @submit.prevent="handleLogin" :aria-label="t('auth.login')">
        <div>
          <label class="block text-sm mb-1" for="login-username">{{ t('auth.username') }}</label>
          <el-input
            id="login-username"
            v-model="form.username"
            :placeholder="t('auth.usernamePlaceholder')"
            size="large"
            :prefix-icon="User"
            autocomplete="username"
            :aria-label="t('auth.username')"
            aria-required="true"
          />
        </div>
        <div>
          <label class="block text-sm mb-1" for="login-password">{{ t('auth.password') }}</label>
          <el-input
            id="login-password"
            v-model="form.password"
            type="password"
            :placeholder="t('auth.passwordPlaceholder')"
            size="large"
            show-password
            :prefix-icon="Lock"
            autocomplete="current-password"
            :aria-label="t('auth.password')"
            aria-required="true"
          />
        </div>
        <el-alert
          v-if="errorMsg"
          :title="errorMsg"
          type="error"
          :closable="false"
          role="alert"
          aria-live="assertive"
        />
        <!-- 🔧 fix(审查): Cloudflare Turnstile 人机验证 (后端配置 SiteKey 后显示) -->
        <div v-if="turnstileLoaded" ref="turnstileWidget" class="flex justify-center py-1"></div>
        <p v-if="turnstileError" class="text-xs text-red-500 text-center">{{ turnstileError }}</p>
        <el-button
          type="primary"
          size="large"
          class="w-full"
          :loading="loading"
          :aria-busy="loading"
          :aria-label="t('auth.login')"
          @click="handleLogin"
        >
          {{ t('auth.login') }}
        </el-button>
      </form>

      <div class="mt-6 text-center text-xs text-muted">
        <div>{{ t('auth.defaultAccount') }}</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* 卡片整体使用 hairline 边框, Musk 风格无阴影 */
.login-card {
  border-radius: 0;
}

/* el-button 在全局样式中已去圆角, 这里仅保证宽度铺满 */
.login-card :deep(.el-button) {
  width: 100%;
}
</style>
